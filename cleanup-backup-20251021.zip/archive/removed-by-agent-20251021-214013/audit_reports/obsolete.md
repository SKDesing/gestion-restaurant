# Obsolete / Temporary Files Report
Generated: 2025-10-21T15:58:37+02:00
\n## Large files (>1MB)
67215129 /home/soufiane/Bureau/gestion restaurant/.next/cache/webpack/server-production/0.pack
53154612 /home/soufiane/Bureau/gestion restaurant/.next/cache/webpack/client-production/0.pack
14184397 /home/soufiane/Bureau/gestion restaurant/.next/cache/webpack/edge-server-production/0.pack
11828429 /home/soufiane/Bureau/gestion restaurant/.next/cache/webpack/server-production/index.pack
11828403 /home/soufiane/Bureau/gestion restaurant/.next/cache/webpack/server-production/index.pack.old
9674472 /home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeExtDexDebug/classes.dex
7400448 /home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeExtDexDebug/classes.dex
7344925 /home/soufiane/Bureau/gestion restaurant/.next/cache/webpack/server-production/1.pack
6604157 /home/soufiane/Bureau/gestion restaurant/eslint_full.json
5675534 /home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/release/app-debug.apk
5675534 /home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/outputs/apk/debug/app-debug.apk
5532480 /home/soufiane/Bureau/gestion restaurant/.next/cache/webpack/server-production/5.pack
5309189 /home/soufiane/Bureau/gestion restaurant/.next/cache/webpack/server-production/3.pack
5291909 /home/soufiane/Bureau/gestion restaurant/.next/cache/webpack/client-production/index.pack
5291440 /home/soufiane/Bureau/gestion restaurant/.next/cache/webpack/client-production/index.pack.old
4666577 /home/soufiane/Bureau/gestion restaurant/.next/cache/webpack/server-production/2.pack
2293500 /home/soufiane/Bureau/gestion restaurant/ESLINT_RUN2.txt
1848510 /home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merger.xml
1761887 /home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/incremental/debug-mergeJavaRes/zip-cache/k8Q9l1b57+gIImx3Ba9skcBGWuQ=
1670469 /home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/incremental/debug-mergeJavaRes/zip-cache/LHgPI2EqozTHaSqAuHCDYwEHaNg=
1492143 /home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/incremental/debug-mergeJavaRes/zip-cache/LWOjsIy7rvlaI+Kq28l4gUhumh8=
1409979 /home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/processed_res/debug/out/resources-debug.ap_
1402946 /home/soufiane/Bureau/gestion restaurant/.next/cache/webpack/edge-server-production/index.pack
1323431 /home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/incremental/debug-mergeJavaRes/zip-cache/WAn8V6wkEH78Qpvt5Qya3ao2opc=
1230050 /home/soufiane/Bureau/gestion restaurant/ESLINT_RUN.txt
1063801 /home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/.gradle/8.1.1/executionHistory/executionHistory.bin
\n## Empty directories
/home/soufiane/Bureau/gestion restaurant/src/app/api/personnel
/home/soufiane/Bureau/gestion restaurant/src/app/api/alertes
/home/soufiane/Bureau/gestion restaurant/src/server/handlers
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/src/main/assets/_next/Zq7zY7eN5pjDRBlydByPA
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/generated/res/pngs/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/generated/res/resValues/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/data_binding_layout_info_type_merge/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/duplicate_classes_check/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/validate_signing_config/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/13
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/8
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/2
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/12
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/3
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/14
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/4
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/11
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/5
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/0
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/15
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/1
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/7
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/6
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/9
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/dex/debug/mergeLibDexDebug/10
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/incremental/debug/packageDebugResources/stripped.dir
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/incremental/debug/packageDebugResources/merged.dir
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/stripped.dir
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/external_file_lib_dex_archives/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/merged_jni_libs/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/data_binding_layout_info_type_package/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/aar_metadata_check/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app/app/build/intermediates/merged_shaders/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app/.gradle/kotlin/errors
/home/soufiane/Bureau/gestion restaurant/android-pos-app/.gradle/9.1.0/expanded
/home/soufiane/Bureau/gestion restaurant/android-pos-app/.gradle/9.1.0/vcsMetadata
/home/soufiane/Bureau/gestion restaurant/android-pos-app/.gradle/9.0-milestone-1/expanded
/home/soufiane/Bureau/gestion restaurant/android-pos-app/.gradle/9.0-milestone-1/vcsMetadata
/home/soufiane/Bureau/gestion restaurant/.next/cache/swc/plugins/linux_x86_64_18.0.0
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/src/main/assets/_next/TTirYd588bpdY63f1SfKv
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/generated/res/pngs/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/generated/res/resValues/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/data_binding_layout_info_type_merge/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/duplicate_classes_check/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/validate_signing_config/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/global_synthetics_external_lib/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/global_synthetics_dex/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/13
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/8
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/2
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/12
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/3
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/14
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/4
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/11
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/5
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/15
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/1
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/7
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/6
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeProjectDexDebug/9
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/13
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/8
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/2
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/12
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/3
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/14
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/4
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/11
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/5
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/0
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/15
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/1
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/7
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/6
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/9
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/dex/debug/mergeLibDexDebug/10
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/incremental/debug/packageDebugResources/stripped.dir
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/incremental/debug/packageDebugResources/merged.dir
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/stripped.dir
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/global_synthetics_mixed_scope/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/external_file_lib_dex_archives/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/merged_jni_libs/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/external_libs_dex_archive/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/sub_project_dex_archive/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/otherProjects
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/mixedScopes
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/externalLibs
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/data_binding_layout_info_type_package/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/external_libs_dex_archive_with_artifact_transforms/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/global_synthetics_project/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/mixed_scope_dex_archive/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/global_synthetics_subproject/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/global_synthetics_file_lib/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/aar_metadata_check/debug
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/global_synthetics_external_libs_artifact_transform/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/java_res/debug/out/com/gestionrestaurant/pos
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/merged_shaders/debug/out
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/.gradle/kotlin/errors
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/.gradle/kotlin/sessions
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/.gradle/9.1.0/expanded
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/.gradle/9.1.0/vcsMetadata
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/.gradle/8.1.1/vcsMetadata
\n## Temporary files (.*~, *.tmp, tmp/*, /tmp/)
/home/soufiane/Bureau/gestion restaurant/tmp/analyze_imports.sh
/home/soufiane/Bureau/gestion restaurant/tmp/package.json
/home/soufiane/Bureau/gestion restaurant/tmp/package-lock.json
/home/soufiane/Bureau/gestion restaurant/tmp/analyze_obsolete.sh
/home/soufiane/Bureau/gestion restaurant/tmp/analyze_duplicates.sh
/home/soufiane/Bureau/gestion restaurant/tmp/analyze_dependencies.sh
/home/soufiane/Bureau/gestion restaurant/tmp/auth_test_4001.js
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/tmp/kotlin-classes/debug/com/gestionrestaurant/pos/POSBridge.class
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/tmp/kotlin-classes/debug/com/gestionrestaurant/pos/MainActivity.class
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/tmp/kotlin-classes/debug/META-INF/app_debug.kotlin_module
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/incremental/packageDebug/tmp/debug/dex-renamer-state.txt
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/incremental/packageDebug/tmp/debug/zip-cache/javaResources0
/home/soufiane/Bureau/gestion restaurant/android-pos-app-clean/app/build/intermediates/incremental/packageDebug/tmp/debug/zip-cache/androidResources
\n## Heuristic orphan source files (no incoming imports found)
src/app/api/employees/route.ts
src/app/api/menu/route.ts
src/app/api/orders/takeout/route.ts
src/app/api/suppliers/route.ts
src/app/api/inventory/route.ts
src/app/api/restaurants/route.ts
src/app/api/temperature/route.ts
src/app/api/analytics/route.ts
src/app/api/haccp-alerts/route.ts
src/app/api/health/route.ts
src/app/api/quality/route.ts
src/app/api/reservations/route.ts
src/app/api/cleaning/route.ts
src/lib/tablet-config.ts
src/lib/metrics.ts
