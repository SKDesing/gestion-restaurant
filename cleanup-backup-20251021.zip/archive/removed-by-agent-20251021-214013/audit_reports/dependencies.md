# Dependency Analysis
Generated: 2025-10-21T15:54:10+02:00
\n## package.json (dependencies & devDependencies)
{
  "@dnd-kit/core": "^6.3.1",
  "@dnd-kit/sortable": "^10.0.0",
  "@dnd-kit/utilities": "^3.2.2",
  "@hookform/resolvers": "^5.1.1",
  "@mdxeditor/editor": "^3.39.1",
  "@next-auth/prisma-adapter": "^1.0.4",
  "@prisma/client": "^6.11.1",
  "@radix-ui/react-accordion": "^1.2.11",
  "@radix-ui/react-alert-dialog": "^1.1.14",
  "@radix-ui/react-aspect-ratio": "^1.1.7",
  "@radix-ui/react-avatar": "^1.1.10",
  "@radix-ui/react-checkbox": "^1.3.2",
  "@radix-ui/react-collapsible": "^1.1.11",
  "@radix-ui/react-context-menu": "^2.2.15",
  "@radix-ui/react-dialog": "^1.1.14",
  "@radix-ui/react-dropdown-menu": "^2.1.15",
  "@radix-ui/react-hover-card": "^1.1.14",
  "@radix-ui/react-label": "^2.1.7",
  "@radix-ui/react-menubar": "^1.1.15",
  "@radix-ui/react-navigation-menu": "^1.2.13",
  "@radix-ui/react-popover": "^1.1.14",
  "@radix-ui/react-progress": "^1.1.7",
  "@radix-ui/react-radio-group": "^1.3.7",
  "@radix-ui/react-scroll-area": "^1.2.9",
  "@radix-ui/react-select": "^2.2.5",
  "@radix-ui/react-separator": "^1.1.7",
  "@radix-ui/react-slider": "^1.3.5",
  "@radix-ui/react-slot": "^1.2.3",
  "@radix-ui/react-switch": "^1.2.5",
  "@radix-ui/react-tabs": "^1.1.12",
  "@radix-ui/react-toast": "^1.2.14",
  "@radix-ui/react-toggle": "^1.1.9",
  "@radix-ui/react-toggle-group": "^1.1.10",
  "@radix-ui/react-tooltip": "^1.2.7",
  "@reactuses/core": "^6.0.5",
  "@socket.io/redis-adapter": "^8.3.0",
  "@tailwindcss/postcss": "^4",
  "@tanstack/react-query": "^5.82.0",
  "@tanstack/react-table": "^8.21.3",
  "@types/bcryptjs": "^2.4.6",
  "axios": "^1.10.0",
  "bcryptjs": "^3.0.2",
  "class-variance-authority": "^0.7.1",
  "clsx": "^2.1.1",
  "cmdk": "^1.1.1",
  "date-fns": "^4.1.0",
  "embla-carousel-react": "^8.6.0",
  "express": "^5.1.0",
  "framer-motion": "^12.23.2",
  "input-otp": "^1.4.2",
  "ioredis": "^5.8.1",
  "lucide-react": "^0.525.0",
  "next": "^15.3.5",
  "next-auth": "^4.24.11",
  "next-intl": "^4.3.4",
  "next-themes": "^0.4.6",
  "node-fetch": "^3.3.2",
  "pg": "^8.11.0",
  "prisma": "^6.11.1",
  "react": "^19.0.0",
  "react-day-picker": "^9.8.0",
  "react-dom": "^19.0.0",
  "react-hook-form": "^7.60.0",
  "react-markdown": "^10.1.0",
  "react-resizable-panels": "^3.0.3",
  "react-syntax-highlighter": "^15.6.6",
  "recharts": "^2.15.4",
  "redis": "^5.8.3",
  "sharp": "^0.34.3",
  "socket.io": "^4.8.1",
  "socket.io-client": "^4.8.1",
  "sonner": "^2.0.6",
  "tailwind-merge": "^3.3.1",
  "tailwindcss": "^4",
  "tailwindcss-animate": "^1.0.7",
  "tsx": "^4.20.3",
  "tw-animate-css": "^1.4.0",
  "uuid": "^11.1.0",
  "vaul": "^1.1.2",
  "zod": "^4.0.2",
  "zustand": "^5.0.6"
}
{
  "@commitlint/cli": "^20.1.0",
  "@commitlint/config-conventional": "^20.0.0",
  "@eslint/eslintrc": "^3",
  "@playwright/test": "^1.56.1",
  "@testing-library/jest-dom": "^6.9.1",
  "@testing-library/react": "^16.3.0",
  "@types/node": "^20",
  "@types/react": "^19",
  "@types/react-dom": "^19",
  "@types/redis": "^4.0.11",
  "concurrently": "^9.2.1",
  "eslint": "^9",
  "eslint-config-next": "15.3.5",
  "husky": "^9.1.7",
  "jsdom": "^27.0.1",
  "lint-staged": "^16.2.5",
  "nodemon": "^3.1.10",
  "pino": "^10.1.0",
  "pino-pretty": "^13.1.2",
  "prettier": "^3.6.2",
  "prom-client": "^15.1.3",
  "ts-node": "^10.9.2",
  "typescript": "^5",
  "vitest": "^3.2.4"
}
\n## pnpm list (top-level)
Legend: production dependency, optional only, dev only

nextjs_tailwind_shadcn_ts@0.1.0 /home/soufiane/Bureau/gestion restaurant (PRIVATE)

dependencies:
@dnd-kit/core 6.3.1
@dnd-kit/sortable 10.0.0
@dnd-kit/utilities 3.2.2
@hookform/resolvers 5.2.2
@mdxeditor/editor 3.47.0
@next-auth/prisma-adapter 1.0.7
@prisma/client 6.17.1
@radix-ui/react-accordion 1.2.12
@radix-ui/react-alert-dialog 1.1.15
@radix-ui/react-aspect-ratio 1.1.7
@radix-ui/react-avatar 1.1.10
@radix-ui/react-checkbox 1.3.3
@radix-ui/react-collapsible 1.1.12
@radix-ui/react-context-menu 2.2.16
@radix-ui/react-dialog 1.1.15
@radix-ui/react-dropdown-menu 2.1.16
@radix-ui/react-hover-card 1.1.15
@radix-ui/react-label 2.1.7
@radix-ui/react-menubar 1.1.16
@radix-ui/react-navigation-menu 1.2.14
@radix-ui/react-popover 1.1.15
@radix-ui/react-progress 1.1.7
@radix-ui/react-radio-group 1.3.8
@radix-ui/react-scroll-area 1.2.10
@radix-ui/react-select 2.2.6
@radix-ui/react-separator 1.1.7
@radix-ui/react-slider 1.3.6
@radix-ui/react-slot 1.2.3
@radix-ui/react-switch 1.2.6
@radix-ui/react-tabs 1.1.13
@radix-ui/react-toast 1.2.15
@radix-ui/react-toggle 1.1.10
@radix-ui/react-toggle-group 1.1.11
@radix-ui/react-tooltip 1.2.8
@reactuses/core 6.1.0
@socket.io/redis-adapter 8.3.0
@tailwindcss/postcss 4.1.15
@tanstack/react-query 5.90.5
@tanstack/react-table 8.21.3
@types/bcryptjs 2.4.6
axios 1.12.2
bcryptjs 3.0.2
class-variance-authority 0.7.1
clsx 2.1.1
cmdk 1.1.1
date-fns 4.1.0
embla-carousel-react 8.6.0
express 5.1.0
framer-motion 12.23.24
input-otp 1.4.2
ioredis 5.8.1
lucide-react 0.525.0
next 15.5.6
next-auth 4.24.11
next-intl 4.3.12
next-themes 0.4.6
node-fetch 3.3.2
pg 8.16.3
prisma 6.17.1
react 19.2.0
react-day-picker 9.11.1
react-dom 19.2.0
react-hook-form 7.65.0
react-markdown 10.1.0
react-resizable-panels 3.0.6
react-syntax-highlighter 15.6.6
recharts 2.15.4
redis 5.8.3
sharp 0.34.4
socket.io 4.8.1
socket.io-client 4.8.1
sonner 2.0.7
tailwind-merge 3.3.1
tailwindcss 4.1.15
tailwindcss-animate 1.0.7
tsx 4.20.6
tw-animate-css 1.4.0
uuid 11.1.0
vaul 1.1.2
zod 4.1.12
zustand 5.0.8

devDependencies:
@commitlint/cli 20.1.0
@commitlint/config-conventional 20.0.0
@eslint/eslintrc 3.3.1
@playwright/test 1.56.1
@testing-library/jest-dom 6.9.1
@testing-library/react 16.3.0
@types/node 20.19.22
@types/react 19.2.2
@types/react-dom 19.2.2
@types/redis 4.0.11
concurrently 9.2.1
eslint 9.38.0
eslint-config-next 15.3.5
husky 9.1.7
jsdom 27.0.1
lint-staged 16.2.5
nodemon 3.1.10
pino 10.1.0
pino-pretty 13.1.2
prettier 3.6.2
prom-client 15.1.3
ts-node 10.9.2
typescript 5.9.3
vitest 3.2.4
\n## Duplicate versions (pnpm why / npm ls)
\n### react
Legend: production dependency, optional only, dev only

nextjs_tailwind_shadcn_ts@0.1.0 /home/soufiane/Bureau/gestion restaurant (PRIVATE)

dependencies:
@dnd-kit/core 6.3.1
├─┬ @dnd-kit/accessibility 3.1.1
│ └── react 19.2.0 peer
├─┬ @dnd-kit/utilities 3.2.2
│ └── react 19.2.0 peer
├── react 19.2.0 peer
└─┬ react-dom 19.2.0 peer
  └── react 19.2.0 peer
@dnd-kit/sortable 10.0.0
├─┬ @dnd-kit/core 6.3.1 peer
│ ├─┬ @dnd-kit/accessibility 3.1.1
│ │ └── react 19.2.0 peer
│ ├─┬ @dnd-kit/utilities 3.2.2
│ │ └── react 19.2.0 peer
│ ├── react 19.2.0 peer
│ └─┬ react-dom 19.2.0 peer
│   └── react 19.2.0 peer
├─┬ @dnd-kit/utilities 3.2.2
│ └── react 19.2.0 peer
└── react 19.2.0 peer

devDependencies:
@testing-library/react 16.3.0
├── react 19.2.0 peer
└─┬ react-dom 19.2.0 peer
  └── react 19.2.0 peer
\n### next
Legend: production dependency, optional only, dev only

nextjs_tailwind_shadcn_ts@0.1.0 /home/soufiane/Bureau/gestion restaurant (PRIVATE)

dependencies:
@next-auth/prisma-adapter 1.0.7
└─┬ next-auth 4.24.11 peer
  └── next 15.5.6 peer
next 15.5.6
next-auth 4.24.11
└── next 15.5.6 peer
next-intl 4.3.12
└── next 15.5.6 peer
\n### socket.io
Legend: production dependency, optional only, dev only

nextjs_tailwind_shadcn_ts@0.1.0 /home/soufiane/Bureau/gestion restaurant (PRIVATE)

dependencies:
socket.io 4.8.1
\n### socket.io-client
Legend: production dependency, optional only, dev only

nextjs_tailwind_shadcn_ts@0.1.0 /home/soufiane/Bureau/gestion restaurant (PRIVATE)

dependencies:
socket.io-client 4.8.1
\n### @socket.io/redis-adapter
Legend: production dependency, optional only, dev only

nextjs_tailwind_shadcn_ts@0.1.0 /home/soufiane/Bureau/gestion restaurant (PRIVATE)

dependencies:
@socket.io/redis-adapter 8.3.0
\ndepcheck not installed in PATH; skipping. Install depcheck to enable unused dependency analysis.
