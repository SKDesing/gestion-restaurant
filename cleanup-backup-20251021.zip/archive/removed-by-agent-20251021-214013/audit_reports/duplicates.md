# Duplicate & Similar Files Report
Generated: 2025-10-21T15:53:19+02:00
\n## Identical files (by md5)
0290d4454dcc018aa4adbd50a727b5c8  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rAU/values-en-rAU.xml
0290d4454dcc018aa4adbd50a727b5c8  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rCA/values-en-rCA.xml
0290d4454dcc018aa4adbd50a727b5c8  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rGB/values-en-rGB.xml
0290d4454dcc018aa4adbd50a727b5c8  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rIN/values-en-rIN.xml
043a3f30c5749621f252ba3120dee445  ./android-pos-app-clean/app/build/intermediates/assets/debug/service-alertes.txt
043a3f30c5749621f252ba3120dee445  ./android-pos-app-clean/app/src/main/assets/service-alertes.txt
089b3d6f002675e24fe28ecdbbf61215  ./android-pos-app/app/src/main/assets/_next/static/Zq7zY7eN5pjDRBlydByPA/_buildManifest.js
089b3d6f002675e24fe28ecdbbf61215  ./android-pos-app-clean/app/src/main/assets/_next/static/TTirYd588bpdY63f1SfKv/_buildManifest.js
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/applypatch-msg
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/commit-msg
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/post-applypatch
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/post-checkout
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/post-commit
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/post-merge
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/post-rewrite
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/pre-applypatch
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/pre-auto-gc
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/pre-commit
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/pre-merge-commit
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/prepare-commit-msg
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/pre-push
0b71c2e7d39daa010985d529f1320b37  ./.husky/_/pre-rebase
0bca8b7144d6dbce33f9eb6af89e861d  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v26/values-v26.xml
0bca8b7144d6dbce33f9eb6af89e861d  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v26/values-v26.xml
0c15cd93c77fdd7350c0c60560effd04  ./.env
0c15cd93c77fdd7350c0c60560effd04  ./.env.bak
100836e25b8cde0d45186c51671242c6  ./android-pos-app/app/build/intermediates/merged_manifests/debug/output-metadata.json
100836e25b8cde0d45186c51671242c6  ./android-pos-app-clean/app/build/intermediates/merged_manifests/debug/output-metadata.json
133a6e9b3e48d0fbb879b98a99be3805  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/layout-20cf1316a4021f6c.js
133a6e9b3e48d0fbb879b98a99be3805  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/layout-20cf1316a4021f6c.js
14fd18675072848025edd73b99e8da6d  ./android-pos-app/app/src/main/assets/_next/static/chunks/main-app-00d0f70730d2771a.js
14fd18675072848025edd73b99e8da6d  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/main-app-00d0f70730d2771a.js
15f177d96254b127208f82b873961422  ./android-pos-app-clean/app/build/intermediates/assets/debug/cuisine.txt
15f177d96254b127208f82b873961422  ./android-pos-app-clean/app/src/main/assets/cuisine.txt
16dfa216ed0eaf5821e005449aca1901  ./android-pos-app/app/build/intermediates/assets/debug/personnel.html
16dfa216ed0eaf5821e005449aca1901  ./android-pos-app/app/src/main/assets/personnel.html
18bae71b1e1b2bb25321090a3b563103  ./android-pos-app/app/src/main/assets/_next/static/media/4cf2300e9c8272f7-s.p.woff2
18bae71b1e1b2bb25321090a3b563103  ./android-pos-app-clean/app/src/main/assets/_next/static/media/4cf2300e9c8272f7-s.p.woff2
1914b8e39c4132075e0854a035e28d4d  ./scripts/legacy-server/server-admin.ts
1914b8e39c4132075e0854a035e28d4d  ./server-admin.ts
1ad907a322aca2eff2c64b46ce2046f0  ./android-pos-app/app/build/intermediates/assets/debug/index.html
1ad907a322aca2eff2c64b46ce2046f0  ./android-pos-app/app/src/main/assets/index.html
1d2dc4c34ee73925f46a8f864e82d6d5  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-pt-rBR/values-pt-rBR.xml
1d2dc4c34ee73925f46a8f864e82d6d5  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-pt/values-pt.xml
1de4c4517b1a546585d887dbf08d2510  ./android-pos-app/app/src/main/assets/_next/static/chunks/pages/_app-eb694f3fd49020c8.js
1de4c4517b1a546585d887dbf08d2510  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/pages/_app-eb694f3fd49020c8.js
1f42df907aa432d452907c36d0eeac26  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-attributes.tab_i
1f42df907aa432d452907c36d0eeac26  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab_i
1f92c81cfbb129c7da72f0306da89acc  ./android-pos-app-clean/app/build/intermediates/packaged_res/debug/layout/activity_main.xml
1f92c81cfbb129c7da72f0306da89acc  ./android-pos-app-clean/app/src/main/res/layout/activity_main.xml
1ffc438b0cecb7839cf124789dfb8bd0  ./android-pos-app/app/build/intermediates/assets/debug/accueil.html
1ffc438b0cecb7839cf124789dfb8bd0  ./android-pos-app/app/src/main/assets/accueil.html
20bc9d65b4550044edd6461326db04fa  ./android-pos-app-clean/app/build/intermediates/assets/debug/index.txt
20bc9d65b4550044edd6461326db04fa  ./android-pos-app-clean/app/src/main/assets/index.txt
24a9c97c6886105fdb91da6049383e32  ./android-pos-app/app/src/main/assets/_next/static/chunks/9890-664ec02a95c6e324.js
24a9c97c6886105fdb91da6049383e32  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/9890-664ec02a95c6e324.js
26b60f471eaa4ca08e2608668e1a3114  ./android-pos-app-clean/app/build/intermediates/assets/debug/caisse.html
26b60f471eaa4ca08e2608668e1a3114  ./android-pos-app-clean/app/src/main/assets/caisse.html
26d11f75c16944d867379025d2d7447d  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/cuisine-avancee/page-8f87c74780d720f6.js
26d11f75c16944d867379025d2d7447d  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/cuisine-avancee/page-8f87c74780d720f6.js
2936ed016d9e0750ece337c3586a0483  ./android-pos-app-clean/app/build/intermediates/assets/debug/caisse.txt
2936ed016d9e0750ece337c3586a0483  ./android-pos-app-clean/app/src/main/assets/caisse.txt
2bc230f3a4ed5c8fed673ae6529afb3b  ./auth_debug_body.txt
2bc230f3a4ed5c8fed673ae6529afb3b  ./auth_debug_headers.txt
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/analytics/route-4457d4af9ad0b70b.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/categories/route-e5a54438ba2c35ac.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/cleaning/route-adb42e52bd824c91.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/employees/route-bdd3eb1cdf49588d.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/haccp-alerts/route-82efbc57286a3e24.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/health/route-05f5d17526b42a47.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/inventory/route-c222bf1e759fa235.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/menu/route-21a50efb49a35201.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/newsletter/route-f30a39cf071daf67.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/orders/route-adfa5552e787f65e.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/orders/takeout/route-f1581b508f661211.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/quality/route-b0165b71419f7189.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/reservations/route-58ee8e01e2ab39b0.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/restaurants/route-08e8186749bd855a.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/socketio/route-e9020e286a7cc58b.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/suppliers/route-46cb34771066c718.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/tables/route-f4b84f2df65347e8.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/api/temperature/route-690c3612b21fb404.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/analytics/route-4457d4af9ad0b70b.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/categories/route-e5a54438ba2c35ac.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/cleaning/route-adb42e52bd824c91.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/employees/route-bdd3eb1cdf49588d.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/haccp-alerts/route-82efbc57286a3e24.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/health/route-05f5d17526b42a47.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/inventory/route-c222bf1e759fa235.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/menu/route-21a50efb49a35201.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/newsletter/route-f30a39cf071daf67.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/orders/route-adfa5552e787f65e.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/orders/takeout/route-f1581b508f661211.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/quality/route-b0165b71419f7189.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/reservations/route-58ee8e01e2ab39b0.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/restaurants/route-08e8186749bd855a.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/socketio/route-e9020e286a7cc58b.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/suppliers/route-46cb34771066c718.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/tables/route-f4b84f2df65347e8.js
31243a37c6af2ca51effbb31dbc0c521  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/api/temperature/route-690c3612b21fb404.js
338387edddb7f63009f36286863e0c28  ./android-pos-app-clean/app/build/intermediates/assets/debug/personnel.html
338387edddb7f63009f36286863e0c28  ./android-pos-app-clean/app/src/main/assets/personnel.html
338a866652413d315dac2605f74846fb  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/inputs/source-to-output.tab_i.len
338a866652413d315dac2605f74846fb  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-attributes.tab_i.len
338a866652413d315dac2605f74846fb  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab_i.len
338a866652413d315dac2605f74846fb  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/internal-name-to-source.tab_i.len
338a866652413d315dac2605f74846fb  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/proto.tab_i.len
338a866652413d315dac2605f74846fb  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/source-to-classes.tab_i.len
338a866652413d315dac2605f74846fb  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/subtypes.tab_i.len
338a866652413d315dac2605f74846fb  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/supertypes.tab_i.len
338a866652413d315dac2605f74846fb  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/file-to-id.tab_i.len
338a866652413d315dac2605f74846fb  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/id-to-file.tab_i.len
338a866652413d315dac2605f74846fb  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/lookups.tab_i.len
34f20b3d0a94963326a9805156145d06  ./android-pos-app/app/src/main/assets/_next/static/chunks/7104-9c124b47b1a3605c.js
34f20b3d0a94963326a9805156145d06  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/7104-9c124b47b1a3605c.js
3671862bae0b21c716a0331e6457b87f  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/inputs/source-to-output.tab.keystream
3671862bae0b21c716a0331e6457b87f  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/source-to-classes.tab.keystream
3671862bae0b21c716a0331e6457b87f  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/file-to-id.tab.keystream
3a4caa17d168e920bf1c238703142696  ./scripts/legacy-server/server-serveur.ts
3a4caa17d168e920bf1c238703142696  ./server-serveur.ts
3c106f8cbe759663b407a16084400087  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v16/values-v16.xml
3c106f8cbe759663b407a16084400087  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v16/values-v16.xml
3fac1f34bfc0a0e73122d116961a749f  ./android-pos-app-clean/app/build/intermediates/assets/debug/404.html
3fac1f34bfc0a0e73122d116961a749f  ./android-pos-app-clean/app/src/main/assets/404.html
40b3a4d239564a8e6bc03eff4bb57558  ./android-pos-app/app/src/main/assets/_next/static/chunks/pages/_error-2b3482c094a540b4.js
40b3a4d239564a8e6bc03eff4bb57558  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/pages/_error-2b3482c094a540b4.js
40f3c60b54202e0ed04431464bfaa877  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-attributes.tab.keystream.len
40f3c60b54202e0ed04431464bfaa877  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab.keystream.len
40f3c60b54202e0ed04431464bfaa877  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/internal-name-to-source.tab.keystream.len
42f46ee1967225126315578016f0f9b6  ./android-pos-app/app/build/intermediates/assets/debug/logo.svg
42f46ee1967225126315578016f0f9b6  ./android-pos-app/app/src/main/assets/logo.svg
42f46ee1967225126315578016f0f9b6  ./android-pos-app-clean/app/build/intermediates/assets/debug/logo.svg
42f46ee1967225126315578016f0f9b6  ./android-pos-app-clean/app/src/main/assets/logo.svg
48dee72e9cc5a0e22b4c409ea9d31b20  ./android-pos-app/app/src/main/assets/_next/static/chunks/1684-db3ae46f67d24429.js
48dee72e9cc5a0e22b4c409ea9d31b20  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/1684-db3ae46f67d24429.js
4adcaa38f14b614a17e4471882d2d2ef  ./android-pos-app/app/build/intermediates/assets/debug/favicon.ico
4adcaa38f14b614a17e4471882d2d2ef  ./android-pos-app/app/src/main/assets/favicon.ico
4adcaa38f14b614a17e4471882d2d2ef  ./android-pos-app-clean/app/build/intermediates/assets/debug/favicon.ico
4adcaa38f14b614a17e4471882d2d2ef  ./android-pos-app-clean/app/src/main/assets/favicon.ico
4adcaa38f14b614a17e4471882d2d2ef  ./src/app/favicon.ico
4bb116916ea31eec6fe245869b742323  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ldltr-v21/values-ldltr-v21.xml
4bb116916ea31eec6fe245869b742323  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ldltr-v21/values-ldltr-v21.xml
4bd5cc2b491884e9e567c03e739a3da5  ./android-pos-app/app/src/main/assets/_next/static/chunks/webpack-7f42fb9ae7fa22d9.js
4bd5cc2b491884e9e567c03e739a3da5  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/webpack-7f42fb9ae7fa22d9.js
4e2eb43f53b1aca057303ee48924236a  ./android-pos-app/app/build/intermediates/assets/debug/newsletter-demo.html
4e2eb43f53b1aca057303ee48924236a  ./android-pos-app/app/src/main/assets/newsletter-demo.html
4e75888d2100f3d284ac2177277d1603  ./android-pos-app/app/src/main/assets/_next/static/css/de70bee13400563f.css
4e75888d2100f3d284ac2177277d1603  ./android-pos-app-clean/app/src/main/assets/_next/static/css/de70bee13400563f.css
519a8bd47139cf489f3292648d4642c3  ./android-pos-app-clean/app/build/intermediates/assets/debug/accueil.txt
519a8bd47139cf489f3292648d4642c3  ./android-pos-app-clean/app/src/main/assets/accueil.txt
51dd9315a5636040cd276c04275adb86  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v18/values-v18.xml
51dd9315a5636040cd276c04275adb86  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v18/values-v18.xml
5270b4ddb6700d0a820e6d066744589c  ./tmp/node_modules/combined-stream/License
5270b4ddb6700d0a820e6d066744589c  ./tmp/node_modules/delayed-stream/License
52fad431b4493384deb61bca02e2ff01  ./tmp/node_modules/es-set-tostringtag/tsconfig.json
52fad431b4493384deb61bca02e2ff01  ./tmp/node_modules/gopd/tsconfig.json
54424d2c74628d5e932c56a892cefbf4  ./android-pos-app-clean/app/build/intermediates/assets/debug/cuisine-alertes.html
54424d2c74628d5e932c56a892cefbf4  ./android-pos-app-clean/app/src/main/assets/cuisine-alertes.html
554b4aab41cda64524173e9f7317628a  ./android-pos-app/app/build/intermediates/assets/debug/caisse.html
554b4aab41cda64524173e9f7317628a  ./android-pos-app/app/src/main/assets/caisse.html
5683d520327b09d60f56b7886b264869  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/cuisine/page-f4eaeaac2f7c4183.js
5683d520327b09d60f56b7886b264869  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/cuisine/page-f4eaeaac2f7c4183.js
5a66ea707a2d818badcbff4ac80afb70  ./android-pos-app/app/src/main/assets/_next/static/chunks/3566-5b3047489cb61ef0.js
5a66ea707a2d818badcbff4ac80afb70  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/3566-5b3047489cb61ef0.js
5c6578ccddc7fafa31e23be91d5d47e6  ./android-pos-app/app/build/intermediates/local_only_symbol_list/debug/R-def.txt
5c6578ccddc7fafa31e23be91d5d47e6  ./android-pos-app-clean/app/build/intermediates/local_only_symbol_list/debug/R-def.txt
5c681c2cb7592e27086a79cccfd0c976  ./src/app/api/newsletter/route.ts
5c681c2cb7592e27086a79cccfd0c976  ./src/app/api/orders/route.ts
5e90bb66e62cd17206f0a9b6db407dad  ./scripts/legacy-server/server-cuisine.ts
5e90bb66e62cd17206f0a9b6db407dad  ./server-cuisine.ts
6053f366de83504fabffe9b564d225ba  ./android-pos-app/app/build/intermediates/assets/debug/service-alertes.txt
6053f366de83504fabffe9b564d225ba  ./android-pos-app/app/src/main/assets/service-alertes.txt
61673ad5aef0390913e8e1c34a64d641  ./android-pos-app/app/src/main/assets/_next/static/chunks/framework-823c6b628bab677c.js
61673ad5aef0390913e8e1c34a64d641  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/framework-823c6b628bab677c.js
61e0bad5da6ace89304bc5056c8188b8  ./android-pos-app-clean/app/build/intermediates/assets/debug/newsletter-demo.html
61e0bad5da6ace89304bc5056c8188b8  ./android-pos-app-clean/app/src/main/assets/newsletter-demo.html
6241275e32ee9d0185d4bce250c9005f  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/caisse/page-1ec5d0b62b86b611.js
6241275e32ee9d0185d4bce250c9005f  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/caisse/page-1ec5d0b62b86b611.js
64cdf53fda7038730ba563cfcca0d066  ./android-pos-app/app/build/intermediates/assets/debug/cuisine-alertes.html
64cdf53fda7038730ba563cfcca0d066  ./android-pos-app/app/src/main/assets/cuisine-alertes.html
64d359470adb4b545080e62ae8f74a47  ./scripts/legacy-server/server-caisse.ts
64d359470adb4b545080e62ae8f74a47  ./server-caisse.ts
6701b66e538409ac1f897fc9b0683c62  ./android-pos-app/app/build/intermediates/assets/debug/serveur.html
6701b66e538409ac1f897fc9b0683c62  ./android-pos-app/app/src/main/assets/serveur.html
6784313ee76a18bf47d03f76e878ac64  ./android-pos-app/app/build/intermediates/assets/debug/serveur.txt
6784313ee76a18bf47d03f76e878ac64  ./android-pos-app/app/src/main/assets/serveur.txt
67dc7ad3e7860d8ca8c14bfec8bbbdae  ./android-pos-app/app/build/intermediates/assets/debug/caisse-avancee.txt
67dc7ad3e7860d8ca8c14bfec8bbbdae  ./android-pos-app/app/src/main/assets/caisse-avancee.txt
685d10259b106d21b7ddf4be0d37592f  ./android-pos-app/app/src/main/assets/_next/static/chunks/3891-f675ddfdbd4cf4db.js
685d10259b106d21b7ddf4be0d37592f  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/3891-f675ddfdbd4cf4db.js
6acfb29e6aa4a9014ec33309e04d7bb2  ./android-pos-app/app/build/intermediates/assets/debug/cuisine.html
6acfb29e6aa4a9014ec33309e04d7bb2  ./android-pos-app/app/src/main/assets/cuisine.html
6adc4bc57237e0d634e2629a1daa94f1  ./tmp/node_modules/tldts-core/LICENSE
6adc4bc57237e0d634e2629a1daa94f1  ./tmp/node_modules/tldts/LICENSE
6b3341b8f492d74e3858ea9bec31f9f7  ./android-pos-app-clean/app/build/intermediates/assets/debug/accueil.html
6b3341b8f492d74e3858ea9bec31f9f7  ./android-pos-app-clean/app/src/main/assets/accueil.html
6cae369452aa6e1e82dafac40fb2136d  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/inputs/source-to-output.tab_i
6cae369452aa6e1e82dafac40fb2136d  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/source-to-classes.tab_i
6cae369452aa6e1e82dafac40fb2136d  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/file-to-id.tab_i
6e30a93914f252bdb682d4db323891d1  ./src/app/api/orders/takeout/route.ts
6e30a93914f252bdb682d4db323891d1  ./src/app/api/quality/route.ts
6e30a93914f252bdb682d4db323891d1  ./src/app/api/reservations/route.ts
6e30a93914f252bdb682d4db323891d1  ./src/app/api/restaurants/route.ts
6e30a93914f252bdb682d4db323891d1  ./src/app/api/suppliers/route.ts
6e30a93914f252bdb682d4db323891d1  ./src/app/api/temperature/route.ts
6fc42e5c8d1f7cc7e38bb4dffa3424da  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/caisse-avancee/page-9cbb6a7080768fbd.js
6fc42e5c8d1f7cc7e38bb4dffa3424da  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/caisse-avancee/page-9cbb6a7080768fbd.js
7053d4f24b8d0134d9fe336dbf194d85  ./android-pos-app/app/src/main/assets/_next/static/chunks/4904-733093ee016364b7.js
7053d4f24b8d0134d9fe336dbf194d85  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/4904-733093ee016364b7.js
705e9de2de3627f12d34ef1ec01329f5  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rAU/values-en-rAU.xml
705e9de2de3627f12d34ef1ec01329f5  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rIN/values-en-rIN.xml
70d26a3360593fe53eed5fb74c1a989e  ./android-pos-app/app/build/intermediates/assets/debug/personnel.txt
70d26a3360593fe53eed5fb74c1a989e  ./android-pos-app/app/src/main/assets/personnel.txt
71d515e22c6da2b31c9d37e1cf5a16f7  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/accueil/page-608aed01464b6a8f.js
71d515e22c6da2b31c9d37e1cf5a16f7  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/accueil/page-608aed01464b6a8f.js
73c77adab8d838e6843cab03417a5401  ./android-pos-app/app/build/intermediates/assets/debug/cuisine-avancee.txt
73c77adab8d838e6843cab03417a5401  ./android-pos-app/app/src/main/assets/cuisine-avancee.txt
78091ed48c70b11336ad564e2c924949  ./android-pos-app-clean/app/build/intermediates/assets/debug/serveur.html
78091ed48c70b11336ad564e2c924949  ./android-pos-app-clean/app/src/main/assets/serveur.html
7b7c0ef93df188a852344fc272fc096b  ./android-pos-app/app/src/main/assets/_next/static/media/9610d9e46709d722-s.woff2
7b7c0ef93df188a852344fc272fc096b  ./android-pos-app-clean/app/src/main/assets/_next/static/media/9610d9e46709d722-s.woff2
7bbf004bae6a305c3bceba613f2fdda4  ./android-pos-app/app/src/main/assets/_next/static/chunks/9572-f12b19623059e5f3.js
7bbf004bae6a305c3bceba613f2fdda4  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/9572-f12b19623059e5f3.js
7d1dd93e0e15b998bbcb86d4f400a674  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/serveur/page-b4a3b77d59cc8566.js
7d1dd93e0e15b998bbcb86d4f400a674  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/serveur/page-b4a3b77d59cc8566.js
7fbe3cf69a7483066df730c9714f8aa5  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-xlarge-v4/values-xlarge-v4.xml
7fbe3cf69a7483066df730c9714f8aa5  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-xlarge-v4/values-xlarge-v4.xml
8118923eebd23b586bde82832adcbc81  ./npm_audit_full.json
8118923eebd23b586bde82832adcbc81  ./npm_audit_prod.json
846118c33b2c0e922d7b3a7676f81f6f  ./android-pos-app/app/src/main/assets/_next/static/chunks/polyfills-42372ed130431b0a.js
846118c33b2c0e922d7b3a7676f81f6f  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/polyfills-42372ed130431b0a.js
846118c33b2c0e922d7b3a7676f81f6f  ./.next/static/chunks/polyfills.js
84e0ad6c3d8aa02fc71e885edd971a38  ./android-pos-app/app/build/intermediates/assets/debug/index.txt
84e0ad6c3d8aa02fc71e885edd971a38  ./android-pos-app/app/src/main/assets/index.txt
8544047e8e1465cd13540f55c69ef508  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/cuisine-alertes/page-84549a3065d1a366.js
8544047e8e1465cd13540f55c69ef508  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/cuisine-alertes/page-84549a3065d1a366.js
86332224a26007387786b1ad1267d1e6  ./android-pos-app/app/src/main/assets/_next/static/chunks/main-b8f2b0fc3240f72d.js
86332224a26007387786b1ad1267d1e6  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/main-b8f2b0fc3240f72d.js
86c44e289b83d5615331a05360b367b7  ./android-pos-app-clean/app/build/intermediates/assets/debug/newsletter-demo.txt
86c44e289b83d5615331a05360b367b7  ./android-pos-app-clean/app/src/main/assets/newsletter-demo.txt
887e933c0fe338dfad0cee41fe401b05  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-watch-v20/values-watch-v20.xml
887e933c0fe338dfad0cee41fe401b05  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-watch-v20/values-watch-v20.xml
8971778a9cc0ad74eeea6d9ed8a7b87f  ./tmp/node_modules/http-cookie-agent/dist/types/undici_redirect_handler.d.js
8971778a9cc0ad74eeea6d9ed8a7b87f  ./tmp/node_modules/http-cookie-agent/dist/types/undici_symbols.d.js
8a80554c91d9fca8acb82f023de02f11  ./pnpm_audit_full.json
8a80554c91d9fca8acb82f023de02f11  ./pnpm_audit_prod.json
8cce24e88dca35fb1176e43e6cc634f8  ./android-pos-app/app/src/main/assets/_next/static/chunks/640-e360c6ef8c79485c.js
8cce24e88dca35fb1176e43e6cc634f8  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/640-e360c6ef8c79485c.js
8ea4f719af3312a055caf09f34c89a77  ./android-pos-app/app/src/main/assets/_next/static/media/ba015fad6dcf6784-s.woff2
8ea4f719af3312a055caf09f34c89a77  ./android-pos-app-clean/app/src/main/assets/_next/static/media/ba015fad6dcf6784-s.woff2
8fab01a041104fe7ad7eee0b26c50193  ./android-pos-app/app/build/intermediates/compressed_assets/debug/out/assets/robots.txt.jar
8fab01a041104fe7ad7eee0b26c50193  ./android-pos-app-clean/app/build/intermediates/compressed_assets/debug/out/assets/robots.txt.jar
8fe23ea421aaf9f9d687709f6a6a09b7  ./tmp/node_modules/call-bind-apply-helpers/LICENSE
8fe23ea421aaf9f9d687709f6a6a09b7  ./tmp/node_modules/es-define-property/LICENSE
8fe23ea421aaf9f9d687709f6a6a09b7  ./tmp/node_modules/es-errors/LICENSE
8fe23ea421aaf9f9d687709f6a6a09b7  ./tmp/node_modules/es-object-atoms/LICENSE
93b885adfe0da089cdf634904fd59f71  ./android-pos-app-clean/.gradle/8.1.1/fileChanges/last-build.bin
93b885adfe0da089cdf634904fd59f71  ./android-pos-app-clean/.gradle/9.1.0/fileChanges/last-build.bin
93b885adfe0da089cdf634904fd59f71  ./android-pos-app/.gradle/4.4.1/fileChanges/last-build.bin
93b885adfe0da089cdf634904fd59f71  ./android-pos-app/.gradle/9.0-milestone-1/fileChanges/last-build.bin
93b885adfe0da089cdf634904fd59f71  ./android-pos-app/.gradle/9.1.0/fileChanges/last-build.bin
93e6dfc724aa11997dc7c9ba56e800f8  ./src/app/api/analytics/route.ts
93e6dfc724aa11997dc7c9ba56e800f8  ./src/app/api/cleaning/route.ts
93e6dfc724aa11997dc7c9ba56e800f8  ./src/app/api/employees/route.ts
93e6dfc724aa11997dc7c9ba56e800f8  ./src/app/api/haccp-alerts/route.ts
93e6dfc724aa11997dc7c9ba56e800f8  ./src/app/api/health/route.ts
93e6dfc724aa11997dc7c9ba56e800f8  ./src/app/api/inventory/route.ts
9403d57cd692e9dfb13116cfce7ad981  ./tmp/node_modules/tldts-core/dist/cjs/src/lookup/interface.js.map
9403d57cd692e9dfb13116cfce7ad981  ./tmp/node_modules/tldts-core/dist/es6/src/lookup/interface.js.map
95360fb3b373e2f955d061bbe5183912  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-hdpi-v4/values-hdpi-v4.xml
95360fb3b373e2f955d061bbe5183912  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-hdpi-v4/values-hdpi-v4.xml
9883c6b9f1bb1ef3af7e372af87b498b  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/service-alertes/page-43aac4a92fb5495b.js
9883c6b9f1bb1ef3af7e372af87b498b  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/service-alertes/page-43aac4a92fb5495b.js
99914b932bd37a50b983c5e7c90ae93b  ./android-pos-app/app/build/intermediates/annotation_processor_list/debug/annotationProcessors.json
99914b932bd37a50b983c5e7c90ae93b  ./android-pos-app-clean/app/build/intermediates/annotation_processor_list/debug/annotationProcessors.json
99914b932bd37a50b983c5e7c90ae93b  ./.next/cache/next-devtools-config.json
99914b932bd37a50b983c5e7c90ae93b  ./.next/react-loadable-manifest.json
99914b932bd37a50b983c5e7c90ae93b  ./.next/server/app-paths-manifest.json
99914b932bd37a50b983c5e7c90ae93b  ./.next/server/pages-manifest.json
99ac946b05b2ae2211a1250f1a700392  ./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/dirs_bucket_0/graph.bin
99ac946b05b2ae2211a1250f1a700392  ./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/dirs_bucket_1/graph.bin
99ac946b05b2ae2211a1250f1a700392  ./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/dirs_bucket_2/graph.bin
99ac946b05b2ae2211a1250f1a700392  ./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/dirs_bucket_3/graph.bin
99ac946b05b2ae2211a1250f1a700392  ./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/jar_d16f66f0d5799e7b1aeffc4bab8a6201208cc358b60ec8dbe2e338a393e6801c_bucket_0/graph.bin
99ac946b05b2ae2211a1250f1a700392  ./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/jar_d16f66f0d5799e7b1aeffc4bab8a6201208cc358b60ec8dbe2e338a393e6801c_bucket_1/graph.bin
99ac946b05b2ae2211a1250f1a700392  ./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/jar_d16f66f0d5799e7b1aeffc4bab8a6201208cc358b60ec8dbe2e338a393e6801c_bucket_2/graph.bin
99ac946b05b2ae2211a1250f1a700392  ./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/jar_d16f66f0d5799e7b1aeffc4bab8a6201208cc358b60ec8dbe2e338a393e6801c_bucket_3/graph.bin
9b2f92a8b3f353c620be93540a413131  ./android-pos-app-clean/app/build/intermediates/assets/debug/cuisine-avancee.html
9b2f92a8b3f353c620be93540a413131  ./android-pos-app-clean/app/src/main/assets/cuisine-avancee.html
9b942886d9ad134105abae36f4012f2d  ./android-pos-app-clean/app/build/intermediates/merged_manifest/debug/AndroidManifest.xml
9b942886d9ad134105abae36f4012f2d  ./android-pos-app-clean/app/build/intermediates/merged_manifests/debug/AndroidManifest.xml
9b942886d9ad134105abae36f4012f2d  ./android-pos-app-clean/app/build/intermediates/packaged_manifests/debug/AndroidManifest.xml
9f3d79dfae1779a468672da34e2394f9  ./android-pos-app-clean/app/build/intermediates/assets/debug/caisse-avancee.txt
9f3d79dfae1779a468672da34e2394f9  ./android-pos-app-clean/app/src/main/assets/caisse-avancee.txt
9fa030b8a8058b236141d30b1d7dadf6  ./android-pos-app/app/build/intermediates/assets/debug/cuisine-alertes.txt
9fa030b8a8058b236141d30b1d7dadf6  ./android-pos-app/app/src/main/assets/cuisine-alertes.txt
a0761690ccf4441ace5cec893b82d4ab  ./android-pos-app/app/src/main/assets/_next/static/media/747892c23ea88013-s.woff2
a0761690ccf4441ace5cec893b82d4ab  ./android-pos-app-clean/app/src/main/assets/_next/static/media/747892c23ea88013-s.woff2
a085652664afd52b93362aa47a959083  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/_not-found/page-d32dab383778e9dc.js
a085652664afd52b93362aa47a959083  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/_not-found/page-d32dab383778e9dc.js
a305ea082c5f6a033bd2404984f8f088  ./tmp/node_modules/es-object-atoms/.eslintrc
a305ea082c5f6a033bd2404984f8f088  ./tmp/node_modules/math-intrinsics/.eslintrc
a5b1dd92a77a6632ebcc7425b08e9078  ./tmp/node_modules/dunder-proto/LICENSE
a5b1dd92a77a6632ebcc7425b08e9078  ./tmp/node_modules/math-intrinsics/LICENSE
a7ef62a133eed5bbaa2a23637d04d13b  ./tmp/node_modules/http-cookie-agent/dist/cookie_options.js
a7ef62a133eed5bbaa2a23637d04d13b  ./tmp/node_modules/http-cookie-agent/dist/types/global_fetch.d.js
aaadc1231f8b49f6ba6f7c7085ab7de2  ./android-pos-app/app/build/intermediates/merged_manifest/debug/AndroidManifest.xml
aaadc1231f8b49f6ba6f7c7085ab7de2  ./android-pos-app/app/build/intermediates/merged_manifests/debug/AndroidManifest.xml
aaadc1231f8b49f6ba6f7c7085ab7de2  ./android-pos-app/app/build/intermediates/packaged_manifests/debug/AndroidManifest.xml
acf687e5145d8156e1e13979652a05b9  ./android-pos-app-clean/app/build/intermediates/assets/debug/cuisine.html
acf687e5145d8156e1e13979652a05b9  ./android-pos-app-clean/app/src/main/assets/cuisine.html
ad1dcf92e6c434b18db406f6ba1282f9  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/newsletter-demo/page-39bcec9b5559d756.js
ad1dcf92e6c434b18db406f6ba1282f9  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/newsletter-demo/page-39bcec9b5559d756.js
af451f127469d6255d2f3389b07b4d36  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab
af451f127469d6255d2f3389b07b4d36  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/internal-name-to-source.tab
b11b581c5847ce7cbdceae9556566350  ./android-pos-app-clean/app/build/intermediates/assets/debug/cuisine-alertes.txt
b11b581c5847ce7cbdceae9556566350  ./android-pos-app-clean/app/src/main/assets/cuisine-alertes.txt
b30b6713309ea252e30aba30461c7a02  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v25/values-v25.xml
b30b6713309ea252e30aba30461c7a02  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v25/values-v25.xml
b404e23d62d95bafd03ad7747cc0e88b  ./android-pos-app/app/src/main/assets/_next/static/Zq7zY7eN5pjDRBlydByPA/_ssgManifest.js
b404e23d62d95bafd03ad7747cc0e88b  ./android-pos-app-clean/app/src/main/assets/_next/static/TTirYd588bpdY63f1SfKv/_ssgManifest.js
b44213c9f1f0334aadfd0a6bbccb5f16  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/page-e40f41dc2c0a3e39.js
b44213c9f1f0334aadfd0a6bbccb5f16  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/page-e40f41dc2c0a3e39.js
b9246e26f9d1fea1b169bc24b2004dfc  ./android-pos-app/app/build/intermediates/assets/debug/caisse.txt
b9246e26f9d1fea1b169bc24b2004dfc  ./android-pos-app/app/src/main/assets/caisse.txt
ba7bba29b93d92fffc2b4625d6860414  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab.values.at
ba7bba29b93d92fffc2b4625d6860414  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/internal-name-to-source.tab.values.at
ba7bba29b93d92fffc2b4625d6860414  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/id-to-file.tab.values.at
bd588a782a4fe62c25b44342c8dbb173  ./android-pos-app/.idea/.gitignore
bd588a782a4fe62c25b44342c8dbb173  ./.idea/.gitignore
bddf8731d219ce68b367bf8d0e0ca140  ./auth_json_body.txt
bddf8731d219ce68b367bf8d0e0ca140  ./auth_json_headers.txt
bef25b69cf50db8ceafd2852b4f10f95  ./android-pos-app/app/build/intermediates/compressed_assets/debug/out/assets/logo.svg.jar
bef25b69cf50db8ceafd2852b4f10f95  ./android-pos-app-clean/app/build/intermediates/compressed_assets/debug/out/assets/logo.svg.jar
bf506358a9877927af3a968e02076283  ./android-pos-app/app/build/intermediates/compatible_screen_manifest/debug/output-metadata.json
bf506358a9877927af3a968e02076283  ./android-pos-app-clean/app/build/intermediates/compatible_screen_manifest/debug/output-metadata.json
bfce5014f3af863450510f1f60f9cc69  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-port/values-port.xml
bfce5014f3af863450510f1f60f9cc69  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-port/values-port.xml
c18d4d6dadff1d28459fcc0e096f50c0  ./android-pos-app/app/src/main/assets/_next/static/chunks/8560-62bbff93bf47ebb1.js
c18d4d6dadff1d28459fcc0e096f50c0  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/8560-62bbff93bf47ebb1.js
c27f173bfbb66c50d383bf43fff6b303  ./android-pos-app/app/build/intermediates/assets/debug/accueil.txt
c27f173bfbb66c50d383bf43fff6b303  ./android-pos-app/app/src/main/assets/accueil.txt
c28b0fe9be6e306cc2ad30fe00e3db10  ./tmp/node_modules/dunder-proto/.eslintrc
c28b0fe9be6e306cc2ad30fe00e3db10  ./tmp/node_modules/es-errors/.eslintrc
c28b0fe9be6e306cc2ad30fe00e3db10  ./tmp/node_modules/hasown/.eslintrc
c28b0fe9be6e306cc2ad30fe00e3db10  ./tmp/node_modules/has-tostringtag/.eslintrc
c2ab942102236f987048d0d84d73d960  ./tmp/node_modules/dunder-proto/.nycrc
c2ab942102236f987048d0d84d73d960  ./tmp/node_modules/function-bind/.nycrc
c2ab942102236f987048d0d84d73d960  ./tmp/node_modules/hasown/.nycrc
c2ab942102236f987048d0d84d73d960  ./tmp/node_modules/has-tostringtag/.nycrc
c2e3b39139beb0954fa479daa9ee6df3  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v22/values-v22.xml
c2e3b39139beb0954fa479daa9ee6df3  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v22/values-v22.xml
c3c30daf2b147dc591267a11ee5d0b3d  ./android-pos-app-clean/app/build/intermediates/assets/debug/caisse-avancee.html
c3c30daf2b147dc591267a11ee5d0b3d  ./android-pos-app-clean/app/src/main/assets/caisse-avancee.html
c3f5f17034342c2e372f066a546d10b5  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/inputs/source-to-output.tab.len
c3f5f17034342c2e372f066a546d10b5  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-attributes.tab.len
c3f5f17034342c2e372f066a546d10b5  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab.len
c3f5f17034342c2e372f066a546d10b5  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/internal-name-to-source.tab.len
c3f5f17034342c2e372f066a546d10b5  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/source-to-classes.tab.len
c3f5f17034342c2e372f066a546d10b5  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/file-to-id.tab.len
c3f5f17034342c2e372f066a546d10b5  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/id-to-file.tab.len
c518f0eab03d706646df660beeb920cf  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-h720dp-v13/values-h720dp-v13.xml
c518f0eab03d706646df660beeb920cf  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-h720dp-v13/values-h720dp-v13.xml
c71164381d885e7b885eb0ec4d71bd77  ./android-pos-app/app/build/intermediates/assets/debug/cuisine.txt
c71164381d885e7b885eb0ec4d71bd77  ./android-pos-app/app/src/main/assets/cuisine.txt
cc728f6c0adb04da0dfcb0fc436a8ae5  ./android-pos-app/app/src/main/assets/_next/static/media/8d697b304b401681-s.woff2
cc728f6c0adb04da0dfcb0fc436a8ae5  ./android-pos-app-clean/app/src/main/assets/_next/static/media/8d697b304b401681-s.woff2
cebdff6ba4048d824a8b507bc0de1ca3  ./android-pos-app-clean/app/build/intermediates/assets/debug/service-alertes.html
cebdff6ba4048d824a8b507bc0de1ca3  ./android-pos-app-clean/app/src/main/assets/service-alertes.html
cf587742577a4eb8b798c6ed5f2c9141  ./android-pos-app/app/src/main/assets/_next/static/chunks/app/personnel/page-30d6aff2a17a9320.js
cf587742577a4eb8b798c6ed5f2c9141  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/app/personnel/page-30d6aff2a17a9320.js
d0104f79f0b4f03bbcd3b287fa04cf8c  ./tmp/node_modules/call-bind-apply-helpers/.nycrc
d0104f79f0b4f03bbcd3b287fa04cf8c  ./tmp/node_modules/es-define-property/.nycrc
d0104f79f0b4f03bbcd3b287fa04cf8c  ./tmp/node_modules/es-set-tostringtag/.nycrc
d0104f79f0b4f03bbcd3b287fa04cf8c  ./tmp/node_modules/get-intrinsic/.nycrc
d0104f79f0b4f03bbcd3b287fa04cf8c  ./tmp/node_modules/get-proto/.nycrc
d0104f79f0b4f03bbcd3b287fa04cf8c  ./tmp/node_modules/has-symbols/.nycrc
d13484569adfc2901dc744aaba407907  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v17/values-v17.xml
d13484569adfc2901dc744aaba407907  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v17/values-v17.xml
d1cc463932a7b3bdc42e427add225e33  ./android-pos-app/app/src/main/assets/_next/static/chunks/1430-d37f08c20dfac4be.js
d1cc463932a7b3bdc42e427add225e33  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/1430-d37f08c20dfac4be.js
d41d8cd98f00b204e9800998ecf8427e  ./android-pos-app-clean/.gradle/8.1.1/dependencies-accessors/gc.properties
d41d8cd98f00b204e9800998ecf8427e  ./android-pos-app-clean/.gradle/8.1.1/gc.properties
d41d8cd98f00b204e9800998ecf8427e  ./android-pos-app-clean/.gradle/9.1.0/gc.properties
d41d8cd98f00b204e9800998ecf8427e  ./android-pos-app-clean/.gradle/vcs-1/gc.properties
d41d8cd98f00b204e9800998ecf8427e  ./android-pos-app/.gradle/9.0-milestone-1/gc.properties
d41d8cd98f00b204e9800998ecf8427e  ./android-pos-app/.gradle/9.1.0/gc.properties
d41d8cd98f00b204e9800998ecf8427e  ./android-pos-app/.gradle/vcs-1/gc.properties
d41d8cd98f00b204e9800998ecf8427e  ./audit_audit_summary_err.log
d41d8cd98f00b204e9800998ecf8427e  ./npm_audit_full.err
d41d8cd98f00b204e9800998ecf8427e  ./npm_audit_readable.err
d41d8cd98f00b204e9800998ecf8427e  ./outdated_err.log
d41d8cd98f00b204e9800998ecf8427e  ./OUTDATED_PACKAGES.err
d41d8cd98f00b204e9800998ecf8427e  ./OUTDATED_READABLE.err
d41d8cd98f00b204e9800998ecf8427e  ./signin_out.txt
d41d8cd98f00b204e9800998ecf8427e  ./ts_build.log
d41d8cd98f00b204e9800998ecf8427e  ./TS_CHECK.txt
d41d8cd98f00b204e9800998ecf8427e  ./tsc_output.txt
d4ab4db413d8ca782382c3d6aed8652d  ./android-pos-app/app/build/intermediates/assets/debug/service-alertes.html
d4ab4db413d8ca782382c3d6aed8652d  ./android-pos-app/app/src/main/assets/service-alertes.html
d61ebf5e84768475bd464bb2f8a2d5fe  ./android-pos-app/app/build/intermediates/assets/debug/newsletter-demo.txt
d61ebf5e84768475bd464bb2f8a2d5fe  ./android-pos-app/app/src/main/assets/newsletter-demo.txt
d751713988987e9331980363e24189ce  ./android-pos-app/app/build/intermediates/navigation_json/debug/navigation.json
d751713988987e9331980363e24189ce  ./android-pos-app-clean/app/build/intermediates/navigation_json/debug/navigation.json
d86189c6c2529c3b4bb9bd8051a32762  ./android-pos-app-clean/app/build/intermediates/assets/debug/personnel.txt
d86189c6c2529c3b4bb9bd8051a32762  ./android-pos-app-clean/app/src/main/assets/personnel.txt
d928a92310bd66161ef213c4fd986049  ./android-pos-app-clean/app/build/outputs/apk/debug/app-debug.apk
d928a92310bd66161ef213c4fd986049  ./android-pos-app-clean/release/app-debug.apk
da83d5f06d825c5ae65b7cca706cb312  ./android-pos-app/app/src/main/assets/_next/static/media/93f479601ee12b01-s.p.woff2
da83d5f06d825c5ae65b7cca706cb312  ./android-pos-app-clean/app/src/main/assets/_next/static/media/93f479601ee12b01-s.p.woff2
dbd47ecbf6b9f8e404216d5186b53aad  ./android-pos-app/app/src/main/assets/_next/static/chunks/4bd1b696-9a0b9381a2f4a392.js
dbd47ecbf6b9f8e404216d5186b53aad  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/4bd1b696-9a0b9381a2f4a392.js
de006cc57bc4ecd49216b721673af44f  ./android-pos-app/app/src/main/assets/_next/static/chunks/3455-d9b9d90bfa5a2cb4.js
de006cc57bc4ecd49216b721673af44f  ./android-pos-app-clean/app/src/main/assets/_next/static/chunks/3455-d9b9d90bfa5a2cb4.js
e0fc41ecb27b220abc292bd1a8902381  ./android-pos-app/app/build/intermediates/assets/debug/404.html
e0fc41ecb27b220abc292bd1a8902381  ./android-pos-app/app/src/main/assets/404.html
e26d5f18a1eab4bb037964300be3baef  ./android-pos-app-clean/app/build/intermediates/assets/debug/cuisine-avancee.txt
e26d5f18a1eab4bb037964300be3baef  ./android-pos-app-clean/app/src/main/assets/cuisine-avancee.txt
e9a739581dcda32844605865e5add4f9  ./android-pos-app/app/build/intermediates/packaged_res/debug/layout/activity_main.xml
e9a739581dcda32844605865e5add4f9  ./android-pos-app/app/src/main/res/layout/activity_main.xml
e9a9435901222c78ecbd30ab31675117  ./android-pos-app/app/build/intermediates/compressed_assets/debug/out/assets/favicon.ico.jar
e9a9435901222c78ecbd30ab31675117  ./android-pos-app-clean/app/build/intermediates/compressed_assets/debug/out/assets/favicon.ico.jar
ec2320e5ae44451938d0a3e209440f78  ./android-pos-app-clean/app/build/intermediates/assets/debug/serveur.txt
ec2320e5ae44451938d0a3e209440f78  ./android-pos-app-clean/app/src/main/assets/serveur.txt
eefedf1be322b9cdb95d0314f1d2a89c  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/subtypes.tab.len
eefedf1be322b9cdb95d0314f1d2a89c  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/supertypes.tab.len
ef34ea1820d99c6d290cd9563deddddf  ./tmp/node_modules/axios-cookiejar-support/LICENSE
ef34ea1820d99c6d290cd9563deddddf  ./tmp/node_modules/http-cookie-agent/LICENSE
f160616b5ff0e0e4667a0b044c4431ed  ./android-pos-app/app/build/intermediates/assets/debug/pos_ui.html
f160616b5ff0e0e4667a0b044c4431ed  ./android-pos-app/app/src/main/assets/pos_ui.html
f17e39b91a2f15fd3c31523dfd01fbdd  ./android-pos-app-clean/app/build/intermediates/assets/debug/index.html
f17e39b91a2f15fd3c31523dfd01fbdd  ./android-pos-app-clean/app/src/main/assets/index.html
f5ebf28b49429b57b900e507d3e1460f  ./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-watch-v21/values-watch-v21.xml
f5ebf28b49429b57b900e507d3e1460f  ./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-watch-v21/values-watch-v21.xml
f76419f79532c1dfe61fd4822bbaea20  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-attributes.tab.keystream
f76419f79532c1dfe61fd4822bbaea20  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab.keystream
f8fbd8c3bab378908ab52971676c5026  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/inputs/source-to-output.tab.keystream.len
f8fbd8c3bab378908ab52971676c5026  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/source-to-classes.tab.keystream.len
f8fbd8c3bab378908ab52971676c5026  ./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/file-to-id.tab.keystream.len
f952c810d0d28260346693afbc4caae1  ./audit_audit_err.log
f952c810d0d28260346693afbc4caae1  ./npm_audit_prod.err
f990ff8272145fe0881924c2bd8e54b9  ./android-pos-app/app/build/intermediates/assets/debug/cuisine-avancee.html
f990ff8272145fe0881924c2bd8e54b9  ./android-pos-app/app/src/main/assets/cuisine-avancee.html
f9dff89adf98833e676de2205921996a  ./android-pos-app/app/build/intermediates/assets/debug/robots.txt
f9dff89adf98833e676de2205921996a  ./android-pos-app/app/src/main/assets/robots.txt
f9dff89adf98833e676de2205921996a  ./android-pos-app-clean/app/build/intermediates/assets/debug/robots.txt
f9dff89adf98833e676de2205921996a  ./android-pos-app-clean/app/src/main/assets/robots.txt
f9dff89adf98833e676de2205921996a  ./public/robots.txt
fc268bb43245258c1eac2a52232d5ea7  ./android-pos-app/app/build/intermediates/assets/debug/caisse-avancee.html
fc268bb43245258c1eac2a52232d5ea7  ./android-pos-app/app/src/main/assets/caisse-avancee.html
fd67163be60a13ca939120c720a25d6d  ./android-pos-app-clean/app/build/intermediates/java_res/debug/out/META-INF/app_debug.kotlin_module
fd67163be60a13ca939120c720a25d6d  ./android-pos-app-clean/app/build/tmp/kotlin-classes/debug/META-INF/app_debug.kotlin_module
fdd7e4435a667de6d5c38df776a312fe  ./android-pos-app/app/build/intermediates/signing_config_versions/debug/signing-config-versions.json
fdd7e4435a667de6d5c38df776a312fe  ./android-pos-app-clean/app/build/intermediates/signing_config_versions/debug/signing-config-versions.json
ff1bbe032d7b50f446ff89488cbcc0ee  ./tsc_after_mailcow_fix.log
ff1bbe032d7b50f446ff89488cbcc0ee  ./tsc_after_reset.log
ff9ca77d93fd9f062b4e81091f36d082  ./android-pos-app/app/build/intermediates/packaged_manifests/debug/output-metadata.json
ff9ca77d93fd9f062b4e81091f36d082  ./android-pos-app-clean/app/build/intermediates/packaged_manifests/debug/output-metadata.json
\n## Files with same basename in different dirs
\n### 005a78e547ae5f4b043e8a841a22f25d436bd1
\n## Heuristic similar files (size + first line)
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-af/values-af.xml\t2969\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-am/values-am.xml\t3144\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ar/values-ar.xml\t3106\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-as/values-as.xml\t3484\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-az/values-az.xml\t3049\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-be/values-be.xml\t3253\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-bg/values-bg.xml\t3282\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-bn/values-bn.xml\t3467\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-b+sr+Latn/values-b+sr+Latn.xml\t3047\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-bs/values-bs.xml\t3038\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ca/values-ca.xml\t3028\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-cs/values-cs.xml\t3013\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-da/values-da.xml\t2959\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-de/values-de.xml\t3036\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-el/values-el.xml\t3356\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rAU/values-en-rAU.xml\t2956\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rCA/values-en-rCA.xml\t2956\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rGB/values-en-rGB.xml\t2956\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rIN/values-en-rIN.xml\t2956\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rXC/values-en-rXC.xml\t11872\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-es-rUS/values-es-rUS.xml\t3022\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-es/values-es.xml\t3044\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-et/values-et.xml\t3034\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-eu/values-eu.xml\t3044\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-fa/values-fa.xml\t3193\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-fi/values-fi.xml\t2985\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-fr-rCA/values-fr-rCA.xml\t3064\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-fr/values-fr.xml\t3053\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-gl/values-gl.xml\t3057\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-gu/values-gu.xml\t3302\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-h720dp-v13/values-h720dp-v13.xml\t130\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-hdpi-v4/values-hdpi-v4.xml\t340\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-hi/values-hi.xml\t3304\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-hr/values-hr.xml\t3025\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-hu/values-hu.xml\t3091\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-hy/values-hy.xml\t3211\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-in/values-in.xml\t3003\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-is/values-is.xml\t2980\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-it/values-it.xml\t2992\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-iw/values-iw.xml\t3114\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ja/values-ja.xml\t3039\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ka/values-ka.xml\t3395\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-kk/values-kk.xml\t3172\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-km/values-km.xml\t3380\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-kn/values-kn.xml\t3537\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ko/values-ko.xml\t3007\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ky/values-ky.xml\t3213\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-land/values-land.xml\t272\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-large-v4/values-large-v4.xml\t760\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ldltr-v21/values-ldltr-v21.xml\t176\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-lo/values-lo.xml\t3321\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-lt/values-lt.xml\t3137\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-lv/values-lv.xml\t3243\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-mk/values-mk.xml\t3230\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ml/values-ml.xml\t3580\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-mn/values-mn.xml\t3204\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-mr/values-mr.xml\t3358\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ms/values-ms.xml\t2992\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-my/values-my.xml\t3575\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-nb/values-nb.xml\t2936\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ne/values-ne.xml\t3536\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-night-v8/values-night-v8.xml\t784\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-nl/values-nl.xml\t3021\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-or/values-or.xml\t3604\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-pa/values-pa.xml\t3248\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-pl/values-pl.xml\t3030\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-port/values-port.xml\t119\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-pt-rBR/values-pt-rBR.xml\t3045\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-pt-rPT/values-pt-rPT.xml\t3039\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-pt/values-pt.xml\t3045\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ro/values-ro.xml\t3070\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ru/values-ru.xml\t3236\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-si/values-si.xml\t3416\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sk/values-sk.xml\t3044\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sl/values-sl.xml\t3046\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sq/values-sq.xml\t3010\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sr/values-sr.xml\t3254\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sv/values-sv.xml\t2995\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sw600dp-v13/values-sw600dp-v13.xml\t619\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sw/values-sw.xml\t2995\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ta/values-ta.xml\t3574\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-te/values-te.xml\t3543\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-th/values-th.xml\t3205\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-tl/values-tl.xml\t3041\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-tr/values-tr.xml\t3006\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-uk/values-uk.xml\t3235\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ur/values-ur.xml\t3238\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-uz/values-uz.xml\t2983\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v16/values-v16.xml\t302\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v17/values-v17.xml\t3553\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v18/values-v18.xml\t112\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v21/values-v21.xml\t19683\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v22/values-v22.xml\t777\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v23/values-v23.xml\t3240\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v24/values-v24.xml\t355\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v25/values-v25.xml\t427\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v26/values-v26.xml\t897\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v28/values-v28.xml\t597\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-vi/values-vi.xml\t3065\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-watch-v20/values-watch-v20.xml\t566\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-watch-v21/values-watch-v21.xml\t737\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-xlarge-v4/values-xlarge-v4.xml\t481\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-zh-rCN/values-zh-rCN.xml\t2980\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-zh-rHK/values-zh-rHK.xml\t2992\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-zh-rTW/values-zh-rTW.xml\t2993\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-zu/values-zu.xml\t2984\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-watch-v20.json\t768\t{
		./android-pos-app/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-watch-v21.json\t769\t{
		./android-pos-app-clean/app/build/intermediates/compressed_assets/debug/out/assets/service-alertes.html.jar\t7270\tPK!!o*'2���assets/service-alertes.html�]�r�F�~��+cO n��RE�sq���,%�I���0(J����۷؟��}��>�~��Ȓ�dc�e�$������ޗ��OO�;<��ŗlZ̢�'��"7��x��5w��'3^�̛��1/�Z�"��Ny;vg|�u�E�dE�yI\���_L�|~z\m�a���{n��L��+��h���3q��f<�ku.b~Ut��-B�3�~�v/�l��Co`�����z�/� �Z���Z*G�$ϓ,���^�Ŋ�-�GY������{�ɹi��=Ԛ�ϧ�������y��}c�*m�0�=;�q��|�p5���>�=t���D�m������C�k歁ףD�ν,Lх���E���^+J[�5�ǯ�΂�S�{���
		./android-pos-app-clean/app/build/intermediates/compressed_assets/debug/out/assets/service-alertes.txt.jar\t2370\tPK!!㇬Oassets/service-alertes.txt�X�n��}�WS?�)�")�*
		./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/dirs_bucket_0/graph.bin\t235\t��sr1com.android.builder.dexing.MutableDependencyGraphLdependentsMaptLjava/util/Map;xpsrjava.util.LinkedHashMap4�N\l��ZaccessOrderxrjava.util.HashMap���`�F
		./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/dirs_bucket_1/graph.bin\t235\t��sr1com.android.builder.dexing.MutableDependencyGraphLdependentsMaptLjava/util/Map;xpsrjava.util.LinkedHashMap4�N\l��ZaccessOrderxrjava.util.HashMap���`�F
		./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/dirs_bucket_2/graph.bin\t235\t��sr1com.android.builder.dexing.MutableDependencyGraphLdependentsMaptLjava/util/Map;xpsrjava.util.LinkedHashMap4�N\l��ZaccessOrderxrjava.util.HashMap���`�F
		./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/dirs_bucket_3/graph.bin\t235\t��sr1com.android.builder.dexing.MutableDependencyGraphLdependentsMaptLjava/util/Map;xpsrjava.util.LinkedHashMap4�N\l��ZaccessOrderxrjava.util.HashMap���`�F
		./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/jar_d16f66f0d5799e7b1aeffc4bab8a6201208cc358b60ec8dbe2e338a393e6801c_bucket_0/graph.bin\t235\t��sr1com.android.builder.dexing.MutableDependencyGraphLdependentsMaptLjava/util/Map;xpsrjava.util.LinkedHashMap4�N\l��ZaccessOrderxrjava.util.HashMap���`�F
		./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/jar_d16f66f0d5799e7b1aeffc4bab8a6201208cc358b60ec8dbe2e338a393e6801c_bucket_1/graph.bin\t235\t��sr1com.android.builder.dexing.MutableDependencyGraphLdependentsMaptLjava/util/Map;xpsrjava.util.LinkedHashMap4�N\l��ZaccessOrderxrjava.util.HashMap���`�F
		./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/jar_d16f66f0d5799e7b1aeffc4bab8a6201208cc358b60ec8dbe2e338a393e6801c_bucket_2/graph.bin\t235\t��sr1com.android.builder.dexing.MutableDependencyGraphLdependentsMaptLjava/util/Map;xpsrjava.util.LinkedHashMap4�N\l��ZaccessOrderxrjava.util.HashMap���`�F
		./android-pos-app-clean/app/build/intermediates/desugar_graph/debug/out/currentProject/jar_d16f66f0d5799e7b1aeffc4bab8a6201208cc358b60ec8dbe2e338a393e6801c_bucket_3/graph.bin\t235\t��sr1com.android.builder.dexing.MutableDependencyGraphLdependentsMaptLjava/util/Map;xpsrjava.util.LinkedHashMap4�N\l��ZaccessOrderxrjava.util.HashMap���`�F
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-af/values-af.xml\t8776\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-am/values-am.xml\t9685\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ar/values-ar.xml\t10044\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-as/values-as.xml\t9739\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-az/values-az.xml\t9000\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-b+es+419/values-b+es+419.xml\t5358\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-be/values-be.xml\t10458\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-bg/values-bg.xml\t10418\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-bn/values-bn.xml\t11228\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-b+sr+Latn/values-b+sr+Latn.xml\t9048\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-bs/values-bs.xml\t9062\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ca/values-ca.xml\t9133\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-cs/values-cs.xml\t9099\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-da/values-da.xml\t8794\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-de/values-de.xml\t9051\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-el/values-el.xml\t10528\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rAU/values-en-rAU.xml\t3675\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rCA/values-en-rCA.xml\t3674\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rGB/values-en-rGB.xml\t8697\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rIN/values-en-rIN.xml\t3675\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-en-rXC/values-en-rXC.xml\t14717\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-es-rUS/values-es-rUS.xml\t9049\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-es/values-es.xml\t9086\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-et/values-et.xml\t8930\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-eu/values-eu.xml\t9011\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-fa/values-fa.xml\t9775\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-fi/values-fi.xml\t8881\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-fr-rCA/values-fr-rCA.xml\t9193\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-fr/values-fr.xml\t9130\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-gl/values-gl.xml\t9173\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-gu/values-gu.xml\t10933\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-h320dp-port-v13/values-h320dp-port-v13.xml\t139\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-h360dp-land-v13/values-h360dp-land-v13.xml\t624\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-h480dp-land-v13/values-h480dp-land-v13.xml\t624\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-h550dp-port-v13/values-h550dp-port-v13.xml\t140\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-h720dp-v13/values-h720dp-v13.xml\t130\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-hdpi-v4/values-hdpi-v4.xml\t340\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-hi/values-hi.xml\t11057\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-hr/values-hr.xml\t9046\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-hu/values-hu.xml\t9120\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-hy/values-hy.xml\t10106\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-in/values-in.xml\t8819\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-is/values-is.xml\t8867\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-it/values-it.xml\t8997\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-iw/values-iw.xml\t9597\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ja/values-ja.xml\t9156\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ka/values-ka.xml\t11283\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-kk/values-kk.xml\t9906\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-km/values-km.xml\t11299\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-kn/values-kn.xml\t11669\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ko/values-ko.xml\t8941\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ky/values-ky.xml\t10177\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-land/values-land.xml\t2949\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-large-v4/values-large-v4.xml\t1900\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ldltr-v21/values-ldltr-v21.xml\t176\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ldrtl-v17/values-ldrtl-v17.xml\t340\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-lo/values-lo.xml\t10880\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-lt/values-lt.xml\t9365\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-lv/values-lv.xml\t9423\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-mk/values-mk.xml\t10139\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ml/values-ml.xml\t12045\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-mn/values-mn.xml\t10005\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-mr/values-mr.xml\t10920\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ms/values-ms.xml\t8855\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-my/values-my.xml\t11750\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-nb/values-nb.xml\t8682\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ne/values-ne.xml\t11540\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-night-v8/values-night-v8.xml\t4546\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-nl/values-nl.xml\t8942\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-or/values-or.xml\t9823\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-pa/values-pa.xml\t10564\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-pl/values-pl.xml\t9088\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-port/values-port.xml\t119\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-pt-rBR/values-pt-rBR.xml\t9058\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-pt-rPT/values-pt-rPT.xml\t9081\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-pt/values-pt.xml\t3783\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ro/values-ro.xml\t9162\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ru/values-ru.xml\t10336\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-si/values-si.xml\t10959\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sk/values-sk.xml\t9100\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sl/values-sl.xml\t9084\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-small-v4/values-small-v4.xml\t348\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sq/values-sq.xml\t9029\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sr/values-sr.xml\t10168\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sv/values-sv.xml\t8858\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sw600dp-v13/values-sw600dp-v13.xml\t1531\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-sw/values-sw.xml\t8941\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ta/values-ta.xml\t11988\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-te/values-te.xml\t11786\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-th/values-th.xml\t10755\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-tl/values-tl.xml\t9116\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-tr/values-tr.xml\t8882\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-uk/values-uk.xml\t10196\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-ur/values-ur.xml\t9911\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-uz/values-uz.xml\t8922\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v16/values-v16.xml\t302\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v17/values-v17.xml\t3553\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v18/values-v18.xml\t112\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v21/values-v21.xml\t38896\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v22/values-v22.xml\t777\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v23/values-v23.xml\t6062\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v24/values-v24.xml\t1555\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v25/values-v25.xml\t427\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v26/values-v26.xml\t897\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v28/values-v28.xml\t1970\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-v31/values-v31.xml\t43153\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values/values.xml\t820832\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-vi/values-vi.xml\t9195\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-w320dp-land-v13/values-w320dp-land-v13.xml\t180\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-w360dp-port-v13/values-w360dp-port-v13.xml\t555\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-w480dp-port-v13/values-w480dp-port-v13.xml\t555\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-w600dp-land-v13/values-w600dp-land-v13.xml\t118\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-watch-v20/values-watch-v20.xml\t566\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-watch-v21/values-watch-v21.xml\t737\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-xlarge-v4/values-xlarge-v4.xml\t481\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-zh-rCN/values-zh-rCN.xml\t8794\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-zh-rHK/values-zh-rHK.xml\t8745\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-zh-rTW/values-zh-rTW.xml\t8781\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/incremental/debug/mergeDebugResources/merged.dir/values-zu/values-zu.xml\t9008\t<?xml version="1.0" encoding="utf-8"?>
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-af.json\t6310\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-am.json\t6282\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ar.json\t6336\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-as.json\t6314\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-az.json\t6316\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-be.json\t6335\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-b+es+419.json\t2014\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-bg.json\t6327\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-bn.json\t6326\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-bs.json\t6330\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-b+sr+Latn.json\t6386\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ca.json\t6326\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-cs.json\t6328\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-da.json\t6306\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-de.json\t6324\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-el.json\t6326\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-en-rAU.json\t2891\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-en-rCA.json\t2891\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-en-rGB.json\t6334\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-en-rIN.json\t2891\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-en-rXC.json\t2962\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-es.json\t6319\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-es-rUS.json\t6351\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-et.json\t6318\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-eu.json\t6322\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-fa.json\t6314\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-fi.json\t6308\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-fr.json\t6323\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-fr-rCA.json\t6359\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-gl.json\t6326\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-gu.json\t6313\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-h320dp-port-v13.json\t711\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-h360dp-land-v13.json\t832\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-h480dp-land-v13.json\t832\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-h550dp-port-v13.json\t711\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-h720dp-v13.json\t692\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-hdpi-v4.json\t721\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-hi.json\t6326\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-hr.json\t6321\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-hu.json\t6312\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-hy.json\t6310\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-in.json\t6314\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-is.json\t6310\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-it.json\t6320\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-iw.json\t6316\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ja.json\t6280\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ka.json\t6310\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-kk.json\t6312\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-km.json\t6306\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-kn.json\t6326\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ko.json\t6276\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ky.json\t6322\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-land.json\t2433\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-large-v4.json\t1772\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ldltr-v21.json\t689\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ldrtl-v17.json\t704\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-lo.json\t6306\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-lt.json\t6340\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-lv.json\t6353\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-mk.json\t6320\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ml.json\t6334\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-mn.json\t6312\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-mr.json\t6318\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ms.json\t6320\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-my.json\t6330\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-nb.json\t6296\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ne.json\t6323\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-night-v8.json\t3116\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-nl.json\t6320\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-or.json\t6319\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-pa.json\t6304\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-pl.json\t6328\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-port.json\t668\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-pt.json\t2875\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-pt-rBR.json\t6352\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-pt-rPT.json\t6352\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ro.json\t6331\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ru.json\t6328\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-si.json\t6314\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-sk.json\t6325\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-sl.json\t6330\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-small-v4.json\t728\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-sq.json\t6320\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-sr.json\t6329\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-sv.json\t6318\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-sw600dp-v13.json\t2070\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-sw.json\t6314\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ta.json\t6330\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-te.json\t6328\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-th.json\t6302\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-tl.json\t6328\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-tr.json\t6306\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-uk.json\t6330\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-ur.json\t6316\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-uz.json\t6312\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-v16.json\t1494\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-v17.json\t1029\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-v18.json\t663\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-v21.json\t10591\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-v22.json\t757\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-v23.json\t3057\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-v24.json\t1774\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-v25.json\t756\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-v26.json\t795\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-v28.json\t2409\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-v31.json\t5501\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-vi.json\t6312\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-w320dp-land-v13.json\t726\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-w360dp-port-v13.json\t816\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-w480dp-port-v13.json\t816\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-w600dp-land-v13.json\t711\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-watch-v20.json\t764\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-watch-v21.json\t765\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-xlarge-v4.json\t763\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-zh-rCN.json\t6304\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-zh-rHK.json\t6302\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-zh-rTW.json\t6303\t{
		./android-pos-app-clean/app/build/intermediates/merged_res_blame_folder/debug/out/multi-v2/values-zu.json\t6321\t{
		./android-pos-app-clean/app/build/intermediates/project_dex_archive/debug/out/com/gestionrestaurant/pos/MainActivity.dex\t2668\tdex
		./android-pos-app-clean/app/build/intermediates/project_dex_archive/debug/out/com/gestionrestaurant/pos/POSBridge.dex\t3396\tdex
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/inputs/source-to-output.tab_i.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/inputs/source-to-output.tab_i\t32768\t�_�*ʈ�.��
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/inputs/source-to-output.tab.keystream.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/inputs/source-to-output.tab.keystream\t4096\tI$PROJECT_DIR$/app/src/main/java/com/gestionrestaurant/pos/MainActivity.ktF$PROJECT_DIR$/app/src/main/java/com/gestionrestaurant/pos/POSBridge.kt
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/inputs/source-to-output.tab.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/inputs/source-to-output.tab\t4096\t�L�����������J���
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/inputs/source-to-output.tab.values.at\t402\t/Header Record For PersistentHashMapValueStorage�]$PROJECT_DIR$/app/build/tmp/kotlin-classes/debug/com/gestionrestaurant/pos/MainActivity.classQ$PROJECT_DIR$/app/build/tmp/kotlin-classes/debug/META-INF/app_debug.kotlin_module�Z$PROJECT_DIR$/app/build/tmp/kotlin-classes/debug/com/gestionrestaurant/pos/POSBridge.classQ$PROJECT_DIR$/app/build/tmp/kotlin-classes/debug/META-INF/app_debug.kotlin_module
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-attributes.tab_i.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-attributes.tab_i\t32768\t���;��N��
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-attributes.tab.keystream.len\t8\tK
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-attributes.tab.keystream\t4096\t&com.gestionrestaurant.pos.MainActivity#com.gestionrestaurant.pos.POSBridge
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-attributes.tab.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-attributes.tab\t4096\t�L�����������'����
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-attributes.tab.values.at\t55\t/Header Record For PersistentHashMapValueStorage
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab_i.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab_i\t32768\t���;��N��
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab.keystream.len\t8\tK
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab.keystream\t4096\t&com.gestionrestaurant.pos.MainActivity#com.gestionrestaurant.pos.POSBridge
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab\t4096\t�L�����������'����
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/class-fq-name-to-source.tab.values.at\t198\t/Header Record For PersistentHashMapValueStorageJI$PROJECT_DIR$/app/src/main/java/com/gestionrestaurant/pos/MainActivity.ktGF$PROJECT_DIR$/app/src/main/java/com/gestionrestaurant/pos/POSBridge.kt
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/internal-name-to-source.tab_i.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/internal-name-to-source.tab_i\t32768\t��[�:*AO
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/internal-name-to-source.tab.keystream.len\t8\tK
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/internal-name-to-source.tab.keystream\t4096\t&com/gestionrestaurant/pos/MainActivity#com/gestionrestaurant/pos/POSBridge
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/internal-name-to-source.tab.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/internal-name-to-source.tab\t4096\t�L�����������'����
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/internal-name-to-source.tab.values.at\t198\t/Header Record For PersistentHashMapValueStorageJI$PROJECT_DIR$/app/src/main/java/com/gestionrestaurant/pos/MainActivity.ktGF$PROJECT_DIR$/app/src/main/java/com/gestionrestaurant/pos/POSBridge.kt
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/proto.tab_i.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/proto.tab_i\t32768\t��[�:*AO�����
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/proto.tab.keystream.len\t8\tZ
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/proto.tab.keystream\t4096\t&com/gestionrestaurant/pos/MainActivity#com/gestionrestaurant/pos/POSBridge.kotlin_module
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/proto.tab.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/proto.tab\t4096\t�L�����������'����K"���
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/proto.tab.values.at\t768\t/Header Record For PersistentHashMapValueStorage�S
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/source-to-classes.tab_i.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/source-to-classes.tab_i\t32768\t�_�*ʈ�.��
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/source-to-classes.tab.keystream.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/source-to-classes.tab.keystream\t4096\tI$PROJECT_DIR$/app/src/main/java/com/gestionrestaurant/pos/MainActivity.ktF$PROJECT_DIR$/app/src/main/java/com/gestionrestaurant/pos/POSBridge.kt
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/source-to-classes.tab.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/source-to-classes.tab\t4096\t�L�����������J����
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/source-to-classes.tab.values.at\t158\t/Header Record For PersistentHashMapValueStorage6&com/gestionrestaurant/pos/MainActivity.kotlin_module3#com/gestionrestaurant/pos/POSBridge.kotlin_module
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/subtypes.tab_i.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/subtypes.tab_i\t32768\t��A�t
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/subtypes.tab.keystream.len\t8\t)
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/subtypes.tab.keystream\t4096\t(androidx.appcompat.app.AppCompatActivity
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/subtypes.tab.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/subtypes.tab\t4096\t�L�����������
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/subtypes.tab.values.at\t90\t/Header Record For PersistentHashMapValueStorage'&com.gestionrestaurant.pos.MainActivity
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/supertypes.tab_i.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/supertypes.tab_i\t32768\t���;�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/supertypes.tab.keystream.len\t8\t'
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/supertypes.tab.keystream\t4096\t&com.gestionrestaurant.pos.MainActivity
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/supertypes.tab.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/supertypes.tab\t4096\t�L�����������
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/jvm/kotlin/supertypes.tab.values.at\t92\t/Header Record For PersistentHashMapValueStorage)(androidx.appcompat.app.AppCompatActivity
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/file-to-id.tab_i.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/file-to-id.tab_i\t32768\t�_�*ʈ�.��
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/file-to-id.tab.keystream.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/file-to-id.tab.keystream\t4096\tI$PROJECT_DIR$/app/src/main/java/com/gestionrestaurant/pos/MainActivity.ktF$PROJECT_DIR$/app/src/main/java/com/gestionrestaurant/pos/POSBridge.kt
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/file-to-id.tab.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/file-to-id.tab\t4096\t�L�����������J����
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/file-to-id.tab.values.at\t61\t/Header Record For PersistentHashMapValueStorage
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/id-to-file.tab_i.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/id-to-file.tab_i\t32768\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/id-to-file.tab.keystream.len\t8\t
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/id-to-file.tab.keystream\t4096\t
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/id-to-file.tab.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/id-to-file.tab\t4096\t�L�����������������
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/id-to-file.tab.values.at\t198\t/Header Record For PersistentHashMapValueStorageJI$PROJECT_DIR$/app/src/main/java/com/gestionrestaurant/pos/MainActivity.ktGF$PROJECT_DIR$/app/src/main/java/com/gestionrestaurant/pos/POSBridge.kt
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/lookups.tab_i.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/lookups.tab_i\t32768\t���d�k�u�ɲ����hX��_@�b��3�U}��"�H�m�n@_��:=��x�x���،h�0����b�4��4k��p���f���Jw�PŰ�4p�+ĝH�w"����s�Z����HD�ĥ��x9nV���%�2����:����(�Lp�䴄}��K�t0�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/lookups.tab.keystream.len\t8\t"�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/lookups.tab.len\t8\t�
		./android-pos-app-clean/app/build/kotlin/compileDebugKotlin/cacheable/caches-jvm/lookups/lookups.tab.values.at\t1431\t/Header Record For PersistentHashMapValueStorage
\n## Potential duplicate declarations (search for duplicate default exports or top-level 'server'/'io' symbols)
