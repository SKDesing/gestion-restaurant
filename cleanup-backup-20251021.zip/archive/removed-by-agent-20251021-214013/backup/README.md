This directory contains automatic backups created during the Socket.IO cleanup and audit.

Files in this folder are read-only snapshots. They were created so we can safely make edits in the repository while retaining the original contents.

Do NOT commit these backups to main branches unless you want to keep them permanently.
